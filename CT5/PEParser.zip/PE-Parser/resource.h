//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PE-Parser.rc
//
#define IDD_SHT_DLG                     102
#define IDD_DATADIR_DLG                 103
#define IDD_IMPORT_DLG                  104
#define IDD_EXPORT_DLG                  105
#define IDI_ICON1                       108
#define IDI_ICON2                       109
#define IDC_OPEN_BTN                    1001
#define IDEXIT                          1002
#define IDD_MAIN_DLG                    1002
#define IDC_FPATH                       1004
#define IDC_SHOWSHT                     1005
#define IDC_SHOWDATADIR                 1006
#define IDC_SHOWEXPORT_BTN              1007
#define IDC_SHOWIMPORT_BTN              1008
#define IDC_EDIT_DH_MAGIC               1009
#define IDC_EDIT_DH_CS                  1010
#define IDC_EDIT_DH_IP                  1011
#define IDC_EDIT_DH_SIZE                1012
#define IDC_EDIT_FH_SIG                 1013
#define IDC_EDIT_FH_MACHINE             1014
#define IDC_EDIT_FH_NUMOFSECTIONS       1015
#define IDC_EDIT_FH_TDS                 1016
#define IDC_EDIT_FH_PTSYMBOL            1017
#define IDC_EDIT_FH_NUMOFSYM            1018
#define IDC_EDIT_FH_SIZEOFOH            1019
#define IDC_EDIT_FH_CHARACTERISTICS     1020
#define IDC_EDIT_OH_EP                  1021
#define IDC_EDIT_OH_IMAGEBASE           1023
#define IDC_EDIT_OH_CODEBASE            1024
#define IDC_SECTIONLIST                 1024
#define IDC_EDIT_OH_DATABASE            1025
#define IDC_EDIT_DD_RVA_EXPORT          1025
#define IDC_IMPORTFUNCTIONS_LIST        1025
#define IDC_EDIT_OH_IMAGESIZE           1026
#define IDC_EDIT_DD_SIZE_EXPORT         1026
#define IDC_EDIT_OH_HEADERSIZE          1027
#define IDC_EDIT_DD_RVA_RES             1027
#define IDC_EDIT_OH_SECTIONALIGN        1028
#define IDC_EDIT_DD_SIZE_RES            1028
#define IDC_EDIT_OH_FILEALIGN           1029
#define IDC_EDIT_DD_RVA_IMPORT          1029
#define IDC_EDIT_OH_SUBSYSTEM           1030
#define IDC_EDIT_DD_SIZE_IMPORT         1030
#define IDC_EDIT_OH_CHECKSUM            1031
#define IDC_EDIT_DD_RVA_EXCEPTION       1031
#define IDC_EDIT_OH_DLLFLAGS            1032
#define IDC_EDIT_DD_SIZE_EXCEPTION      1032
#define IDC_EDIT_DD_RVA_SECURITY        1033
#define IDC_EDIT_DD_SIZE_SECURITY       1034
#define IDC_EDIT_DD_RVA_RELOC           1035
#define IDC_EDIT_DD_SIZE_RELOC          1036
#define IDC_EDIT_DD_RVA_DEBUG           1037
#define IDC_EDIT_DD_SIZE_DEBUG          1038
#define IDC_EDIT_DD_RVA_COPYRIGHT       1039
#define IDC_EDIT_DD_SIZE_COPYRIGHT      1040
#define IDC_EDIT_DD_RVA_GP              1041
#define IDC_EDIT_DD_SIZE_GP             1042
#define IDC_EDIT_DD_RVA_TLS             1043
#define IDC_EDIT_DD_SIZE_TLS            1044
#define IDC_EDIT_DD_RVA_LOADCONFIG      1045
#define IDC_EDIT_DD_SIZE_LOADCONFIG     1046
#define IDC_EDIT_DD_RVA_BOUND           1047
#define IDC_EDIT_DD_SIZE_BOUND          1048
#define IDC_EDIT_DD_RVA_IAT             1049
#define IDC_EDIT_DD_SIZE_IAT            1050
#define IDC_EDIT_DD_RVA_DELAYIMPORT     1051
#define IDC_EDIT_DD_SIZE_DELAYIMPORT    1052
#define IDC_EDIT_DD_RVA_COM             1053
#define IDC_EDIT_DD_SIZE_COM            1054
#define IDC_EDIT_DD_RVA_NOUSE           1055
#define IDC_EDIT_DD_SIZE_NOUSE          1056
#define IDC_OK                          1057
#define IDC_IMPORT_LIST                 1058
#define IDC_EDIT_EXPDIR_CHARACTERISTICS 1059
#define IDC_EDIT_EXPDIR_TDS             1060
#define IDC_EDIT_EXPDIR_MJV             1061
#define IDC_EDIT_EXPDIR_MIV             1062
#define IDC_EDIT_EXPDIR_NAME            1063
#define IDC_EDIT_EXPDIR_BASE            1064
#define IDC_EDIT_EXPDIR_NUMOFFUNCS      1065
#define IDC_EDIT_EXPDIR_NUMOFNAMES      1066
#define IDC_EDIT_EXPDIR_ADDROFFUNCS     1067
#define IDC_EDIT_EXPDIR_ADDROFNAMES     1068
#define IDC_EDIT_EXPDIR_ADDROFNAMEORD   1069
#define IDC_EXPORT_LIST                 1071

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        110
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1073
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
